
#ifndef _NewPackage_get_angles_H
#define _NewPackage_get_angles_H
#include <Rcpp.h>
RcppExport SEXP get_angles(SEXP x, SEXP y) ;
#endif
