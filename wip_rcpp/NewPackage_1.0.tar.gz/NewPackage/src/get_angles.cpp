#include "get_angles.h"
using namespace Rcpp ;
SEXP get_angles(SEXP x, SEXP y){
    NumericMatrix TRAPS(x);
    NumericMatrix MASK(y);
    int K = TRAPS.nrow();
	int M = MASK.nrow();
	NumericMatrix ANGLES(K,M);
	double OPP;
	double ADJ;
	for (int k=0; k<K; k++) {
		for (int m=0; m<M; m++) {
			OPP = MASK(m,0)-TRAPS(k,0);
			ADJ = MASK(m,1)-TRAPS(k,1);
			ANGLES(k,m) = atan(OPP/ADJ);
			if(ADJ<0) ANGLES(k,m) += M_PI;
			if(OPP<0 & ADJ>=0) ANGLES(k,m) += M_2PI;
		}
	}
	return ANGLES;
}
