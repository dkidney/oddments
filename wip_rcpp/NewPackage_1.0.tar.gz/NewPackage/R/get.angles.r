
#' Calculate bearings between points
#'
#' Function to calculate bearings (in radians) from all points in x to all points in y.
#' X and Y must use the same coordinate system.
#' 
#' Used specifically in this package to calculate bearings from all detectors (x) to all mask points (y).
#' Function has been optimized using Rcpp.
#'
#' @param x a K by 2 matrix of detector coordinates. 
#' Column one contains x-coordinates, column two contains y-coordinates.
#' Each row corresponds to a unique detector (K detectors in total).
#' @param y an M by 2 matrix of mask point coordiantes. 
#' Column one contains x-coordinates, column two contains y-coordinates
#' @return Returns a K by M matrix of radians.
#' @author Darren Kidney
#' @seealso \code{\link{get.distances}}
#' @examples
#' X <- matrix(0, nc=2) ; X
#' Y <- as.matrix(rbind(c(0,1),c(1,1))) ; Y
#' get.angles(X, Y) # radians
#' get.angles(X, Y) * 360/(2*pi) # degrees
#' @export
    
get.angles <- function(x,y){
    .Call( "get_angles", x = as.matrix(x), y = as.matrix(y))
}
